﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Lab_title = New System.Windows.Forms.Label()
        Me.But_run = New System.Windows.Forms.Button()
        Me.But_end = New System.Windows.Forms.Button()
        Me.Lab_ques = New System.Windows.Forms.Label()
        Me.Lbox_option = New System.Windows.Forms.ListBox()
        Me.But_choose = New System.Windows.Forms.Button()
        Me.But_restart = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Lab_title
        '
        Me.Lab_title.AutoSize = True
        Me.Lab_title.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lab_title.Font = New System.Drawing.Font("Stencil", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_title.ForeColor = System.Drawing.Color.MediumOrchid
        Me.Lab_title.Location = New System.Drawing.Point(243, 32)
        Me.Lab_title.Name = "Lab_title"
        Me.Lab_title.Size = New System.Drawing.Size(229, 76)
        Me.Lab_title.TabIndex = 0
        Me.Lab_title.Text = "Quest"
        '
        'But_run
        '
        Me.But_run.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.But_run.Location = New System.Drawing.Point(120, 328)
        Me.But_run.Name = "But_run"
        Me.But_run.Size = New System.Drawing.Size(123, 58)
        Me.But_run.TabIndex = 1
        Me.But_run.Text = "Begin adventure"
        Me.But_run.UseVisualStyleBackColor = True
        '
        'But_end
        '
        Me.But_end.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.But_end.Location = New System.Drawing.Point(387, 328)
        Me.But_end.Name = "But_end"
        Me.But_end.Size = New System.Drawing.Size(123, 58)
        Me.But_end.TabIndex = 2
        Me.But_end.Text = "Whimp out"
        Me.But_end.UseVisualStyleBackColor = True
        '
        'Lab_ques
        '
        Me.Lab_ques.AutoSize = True
        Me.Lab_ques.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lab_ques.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_ques.ForeColor = System.Drawing.Color.MediumOrchid
        Me.Lab_ques.Location = New System.Drawing.Point(22, 122)
        Me.Lab_ques.Name = "Lab_ques"
        Me.Lab_ques.Size = New System.Drawing.Size(277, 29)
        Me.Lab_ques.TabIndex = 3
        Me.Lab_ques.Text = "You wake up in your bed"
        '
        'Lbox_option
        '
        Me.Lbox_option.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Lbox_option.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbox_option.FormattingEnabled = True
        Me.Lbox_option.ItemHeight = 23
        Me.Lbox_option.Items.AddRange(New Object() {"Sleep another hour", "Get out of bed"})
        Me.Lbox_option.Location = New System.Drawing.Point(27, 173)
        Me.Lbox_option.Name = "Lbox_option"
        Me.Lbox_option.Size = New System.Drawing.Size(713, 96)
        Me.Lbox_option.TabIndex = 4
        '
        'But_choose
        '
        Me.But_choose.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.But_choose.Location = New System.Drawing.Point(27, 275)
        Me.But_choose.Name = "But_choose"
        Me.But_choose.Size = New System.Drawing.Size(107, 47)
        Me.But_choose.TabIndex = 5
        Me.But_choose.Text = "Choose"
        Me.But_choose.UseVisualStyleBackColor = True
        '
        'But_restart
        '
        Me.But_restart.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.But_restart.Location = New System.Drawing.Point(276, 275)
        Me.But_restart.Name = "But_restart"
        Me.But_restart.Size = New System.Drawing.Size(107, 47)
        Me.But_restart.TabIndex = 6
        Me.But_restart.Text = "Restart"
        Me.But_restart.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Conditional_Statements_3.My.Resources.Resources._13375577475771
        Me.ClientSize = New System.Drawing.Size(959, 621)
        Me.Controls.Add(Me.But_restart)
        Me.Controls.Add(Me.But_choose)
        Me.Controls.Add(Me.Lbox_option)
        Me.Controls.Add(Me.Lab_ques)
        Me.Controls.Add(Me.But_end)
        Me.Controls.Add(Me.But_run)
        Me.Controls.Add(Me.Lab_title)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Lab_title As System.Windows.Forms.Label
    Friend WithEvents But_run As System.Windows.Forms.Button
    Friend WithEvents But_end As System.Windows.Forms.Button
    Friend WithEvents Lab_ques As System.Windows.Forms.Label
    Friend WithEvents Lbox_option As System.Windows.Forms.ListBox
    Friend WithEvents But_choose As System.Windows.Forms.Button
    Friend WithEvents But_restart As System.Windows.Forms.Button

End Class
