﻿


Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Lab_ques.Visible = False
        Lbox_option.Visible = False
        But_choose.Visible = False
        But_restart.Visible = False
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_run.Click
        But_run.Visible = False
        But_run.Enabled = False

        Lab_ques.Visible = True
        Lbox_option.Visible = True
        But_choose.Visible = True
        But_restart.Visible = True

    End Sub


    Private Sub But_end_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_end.Click
        Me.Close()

    End Sub

    Private Sub But_choose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_choose.Click

        Select Case Lbox_option.Text

            Case "Sleep another hour"
                Lab_ques.Text = "A troll enters your house and murders you in your sleep, try again"
                But_choose.Enabled = False
                Lbox_option.Enabled = False
            Case "Get out of bed"
                Lab_ques.Text = "You stand to you feet and get dressed"
                Lbox_option.Items.Add("Put on military fatigues")
                Lbox_option.Items.Remove("Sleep another hour")
                Lbox_option.Items.Remove("Get out of bed")
                Lbox_option.Items.Add("Put on tuxedo")
        End Select

        Select Case Lbox_option.Text
            Case "Put on military fatigues"
                Lab_ques.Text = "Comfortable, good choice. You hear a knock on your door"
                Lbox_option.Items.Remove("Put on military fatigues")
                Lbox_option.Items.Remove("Put on tuxedo")
                Lbox_option.Items.Add("Check window to see who's there")
                Lbox_option.Items.Add("Open front door")
            Case "Put on tuxedo"
                Lab_ques.Text = "Looking sharp. Someone knocks on your door"
                Lbox_option.Items.Remove("Put on military fatigues")
                Lbox_option.Items.Remove("Put on tuxedo")
                Lbox_option.Items.Add("Check window to see who's at door")
                Lbox_option.Items.Add("Open door")
        End Select

        '-----------------------------Fatigues 1 
        Select Case Lbox_option.Text
            Case "Check window to see who's there"
                Lab_ques.Text = "You see a group of trolls at your door"
                Lbox_option.Items.Remove("Open front door")
                Lbox_option.Items.Remove("Check window to see who's there")
                Lbox_option.Items.Add("You figure you can take them and reach for your katana")
                Lbox_option.Items.Add("You figure there are too many and flee for the back door")
            Case "Open front door"
                Lab_ques.Text = "You recieve a broad sword to the jugular by some trolls and die."
                But_choose.Enabled = False
                Lbox_option.Enabled = False
        End Select
        '-----------------------------Tuxedo 1 
        Select Case Lbox_option.Text
            Case "Check window to see who's at door"
                Lab_ques.Text = "You see a band of trolls at your door"
                Lbox_option.Items.Remove("Check window to see who's at door")
                Lbox_option.Items.Remove("Open door")
                Lbox_option.Items.Add("You realize there are too many and flee for the back door")
                Lbox_option.Items.Add("You realize you can take them and reach for your katana")
            Case "Open door"
                Lab_ques.Text = "You are greeted with a sword to the neck from a band of trolls and die."
                But_choose.Enabled = False
                Lbox_option.Enabled = False
        End Select
        '-----------------------------Tuxedo 2
        Select Case Lbox_option.Text
            Case "You realize there are too many and flee for the back door"
                Lab_ques.Text = "You are now in your back yard, without a weapon"
                Lbox_option.Items.Remove("You realize there are too many and flee for the back door")
                Lbox_option.Items.Remove("You realize you can take them and reach for your katana")
                Lbox_option.Items.Add("Knowing your chances you flee into the woods")
                Lbox_option.Items.Add("You attempt to flank the trolls, bare handed")
            Case "You realize you can take them and reach for your katana"
                Lab_ques.Text = "You unsheath your katana prepare for battle"
                Lbox_option.Items.Remove("You realize there are too many and flee for the back door")
                Lbox_option.Items.Remove("You realize you can take them and reach for your katana")
                Lbox_option.Items.Add("You wait for the trolls to break down the door")
                Lbox_option.Items.Add("You open the door and begin the battle")
        End Select

        Select Case Lbox_option.Text
            Case "You attempt to flank the trolls, bare handed"
                Lab_ques.Text = "The trolls take your out because you didn't have a weapon, stupid."
                But_choose.Enabled = False
                Lbox_option.Enabled = False
        End Select

        Select Case Lbox_option.Text
            Case "You wait for the trolls to break down the door"
                Lab_ques.Text = "Because of the tux restricting your movement, your die in battle"
                But_choose.Enabled = False
                Lbox_option.Enabled = False
            Case "You open the door and begin the battle"
                Lab_ques.Text = "The trolls were more prepared than you thought and defeat you"
                But_choose.Enabled = False
                Lbox_option.Enabled = False

        End Select
        '-----------------------------Fatigues 2
        Select Case Lbox_option.Text
            Case "You figure there are too many and flee for the back door"
                Lab_ques.Text = "You are now in your back yard, you find a knife in the fatigue's pocket"
                Lbox_option.Items.Remove("You figure there are too many and flee for the back door")
                Lbox_option.Items.Remove("You figure you can take them and reach for your katana")
                Lbox_option.Items.Add("Knowing your chances you flee into the woods")
                Lbox_option.Items.Add("With the element of surprise you attempt to flank the trolls")


            Case "You figure you can take them and reach for your katana"
                Lab_ques.Text = "You unsheath your blade and stand, in front of the door, at the ready"
                Lbox_option.Items.Remove("You figure there are too many and flee for the back door")
                Lbox_option.Items.Remove("You figure you can take them and reach for your katana")
                Lbox_option.Items.Add("Wait for the trolls to break down door")
                Lbox_option.Items.Add("Open the door and begin the attack")
        End Select

        Select Case Lbox_option.Text
            Case "Wait for the trolls to break down door"
                Lab_ques.Text = "The trolls break in and you take them out without a hassle"
                Lbox_option.Items.Remove("Wait for the trolls to break down door")
                Lbox_option.Items.Remove("Open the door and begin the attack")
                Lbox_option.Items.Add("Good job you win! Now clean up the mess..")
                Lbox_option.Enabled = False
            Case "Open the door and begin the attack"
                Lab_ques.Text = "The trolls were more prepared than you thought and defeat you"
                But_choose.Enabled = False
                Lbox_option.Enabled = False
        End Select

        Select Case Lbox_option.Text
            Case "Knowing your chances you flee into the woods"
                Lab_ques.Text = "In the woods you find the troll's home camp"
                Lbox_option.Items.Remove("Knowing your chances you flee into the woods")
                Lbox_option.Items.Remove("With the element of surprise you attempt to flank the trolls")
                Lbox_option.Items.Remove("You attempt to flank the trolls, bare handed")
                Lbox_option.Items.Add("Assuming the camp's empty, you search it")
                Lbox_option.Items.Add("They probably have trolls on watch, you continue your escape")
            Case "With the element of surprise you attempt to flank the trolls"
                Lab_ques.Text = "You approach the trolls from behind and take out all of them without a hassle"
                Lbox_option.Items.Remove("Knowing your chances you flee into the woods")
                Lbox_option.Items.Remove("With the element of surprise you attempt to flank the trolls")
                Lbox_option.Items.Add("GOOD JOB, YOU WIN!")
                But_choose.Enabled = False
        End Select
        Select Case Lbox_option.Text
            Case "Assuming the camp's empty, you search it"
                Lab_ques.Text = "You you find a troll gaurd but take him out, you loot the camp and return to your home"
                Lbox_option.Items.Remove("Assuming the camp's empty, you search it")
                Lbox_option.Items.Remove("They probably have trolls on watch, you continue your escape")
                Lbox_option.Items.Add("You won! And with all the troll's valuables to replace your own!")
                But_choose.Enabled = False
            Case "They probably have trolls on watch, you continue your escape"
                Lab_ques.Text = "You run further into the woods, wait a reasonable time, and return to your pilleged home"
                Lbox_option.Items.Remove("They probably have trolls on watch, you continue your escape")
                Lbox_option.Items.Remove("Assuming the camp's empty, you search it")
                Lbox_option.Items.Add("You win, but at the cost of all your possesions being stolen by trolls")
                But_choose.Enabled = False
        End Select
    End Sub

    Private Sub But_restart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_restart.Click
        Lab_ques.Text = "You wake up in your bed"
        But_choose.Enabled = True
        Lbox_option.Enabled = True
        Lbox_option.Items.Clear()
        Lbox_option.Items.Add("Sleep another hour")
        Lbox_option.Items.Add("Get out of bed")
    End Sub
End Class
